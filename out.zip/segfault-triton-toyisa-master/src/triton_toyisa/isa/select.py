"""Instruction selection: enumerate, filter fail-closed, min cost, report the gap.

`contracts/selector.md` is the normative spec. The whole module is five small
functions because the schema is small by design (D6 in `research.md`): exhaustive
enumeration *is* the oracle, which is what makes "the generator chose" auditable
rather than asserted (FR-018, SC-005).
"""

from __future__ import annotations

from dataclasses import dataclass

from .schema import Instruction, IsaSchema, cost_of, evaluate

__all__ = ["Candidate", "SelectionReport", "enumerate_candidates", "oracle_min", "select"]


@dataclass(frozen=True)
class Candidate:
    """One instruction's verdict against one operand."""

    instruction: Instruction
    admissible: bool
    rejected_by: str | None  # the predicate text that failed, or "unknown"
    cost: float | None


@dataclass(frozen=True)
class SelectionReport:
    """The full decision: everything enumerated, rejections attributed, gap visible."""

    chosen: Instruction | None
    chosen_cost: float | None
    candidates: tuple[Candidate, ...] = ()
    oracle_min_cost: float | None = None
    oracle_chosen: Instruction | None = None
    gap: float = 0.0
    no_admissible_lowering: bool = False


def enumerate_candidates(
    schema: IsaSchema,
    kind: str,
    descriptor: object,
    tile: tuple[int, ...] | None = None,
    env: dict[str, int] | None = None,
) -> tuple[Candidate, ...]:
    """Every instruction of `kind` against this operand, including rejected ones.

    Postcondition 1: nothing is pre-filtered — the rejected rows are the audit
    trail. Postcondition 2: a rejection names the failing predicate's *text*
    (never `"unknown"` as a reason string; an undecidable predicate is recorded
    with the literal verdict so the reason is visible).
    """

    def reason_of(instruction: object) -> str:
        """The predicate's author text, whatever shape the schema stores it in.

        The real schema stores parsed `Predicate` objects; the frozen stand-in
        (`qc/standin.py`) stores the raw string. Both must yield the *text*,
        because postcondition 2's rejection reason is the predicate the author
        wrote, and a schema shape difference must not change what is reported.
        """
        constraint = getattr(instruction, "constraint", "")
        return constraint if isinstance(constraint, str) else constraint.text

    out: list[Candidate] = []
    for instruction in schema.of_kind(kind):
        verdict = evaluate(reason_of(instruction), descriptor, tile, env)
        if verdict is True:
            cost: float | None = cost_of(instruction, descriptor, tile, env)
            out.append(Candidate(instruction, True, None, cost))
        else:
            text = reason_of(instruction)
            reason = text if verdict is False else f"unknown: {text}"
            out.append(Candidate(instruction, False, reason, None))
    return tuple(out)


def select(
    schema: IsaSchema,
    kind: str,
    descriptor: object,
    tile: tuple[int, ...] | None = None,
    env: dict[str, int] | None = None,
) -> SelectionReport:
    """Minimum cost among the admissible; no default fallback.

    Postcondition 3: ties break by schema declaration order — `min` over
    `(cost, declaration_index)` is deterministic because `of_kind` is ordered.
    Postcondition 4: nothing admissible means `chosen is None` and
    `no_admissible_lowering=True`; the emitter turns that into `UNSUPPORTED`.
    Postcondition 5: `oracle_min` runs the same enumeration the other way, and
    the gap is reported, not hidden (SC-005, EC-072).
    """
    candidates = enumerate_candidates(schema, kind, descriptor, tile, env)
    admissible = [c for c in candidates if c.admissible and c.cost is not None]
    if not admissible:
        oracle = oracle_min(schema, kind, descriptor, tile, env)
        return SelectionReport(
            chosen=None,
            chosen_cost=None,
            candidates=candidates,
            oracle_min_cost=oracle.oracle_min_cost,
            oracle_chosen=None,
            gap=0.0,
            no_admissible_lowering=True,
        )
    # Tie-break by enumeration position: `of_kind` returns declaration order on
    # every schema shape (the real one sorts by `declaration_index`; the stand-in
    # preserves its tuple), so position *is* the deterministic tie-break without
    # depending on an attribute the stand-in does not carry.
    order = {id(c.instruction): i for i, c in enumerate(candidates)}
    best = min(admissible, key=lambda c: (c.cost, order[id(c.instruction)]))
    oracle = oracle_min(schema, kind, descriptor, tile, env)
    gap = max(0.0, (best.cost or 0.0) - (oracle.oracle_min_cost or 0.0))
    return SelectionReport(
        chosen=best.instruction,
        chosen_cost=best.cost,
        candidates=candidates,
        oracle_min_cost=oracle.oracle_min_cost,
        oracle_chosen=oracle.oracle_chosen,
        gap=gap,
        no_admissible_lowering=False,
    )


def oracle_min(
    schema: IsaSchema,
    kind: str,
    descriptor: object,
    tile: tuple[int, ...] | None = None,
    env: dict[str, int] | None = None,
) -> SelectionReport:
    """The exhaustive oracle: same enumeration, optimum reported separately.

    On this schema the greedy rule (min cost among admissible) and the oracle
    agree by construction — there is no coupling between instructions, because
    one operand maps to exactly one instruction. The function exists so the
    *report* carries the oracle column and a future ISA with coupled costs
    (ISA-2's bank moves) cannot silently drop the comparison (SC-005).
    """
    candidates = enumerate_candidates(schema, kind, descriptor, tile, env)
    admissible = [c for c in candidates if c.admissible and c.cost is not None]
    if not admissible:
        return SelectionReport(
            chosen=None,
            chosen_cost=None,
            candidates=candidates,
            oracle_min_cost=None,
            oracle_chosen=None,
            gap=0.0,
            no_admissible_lowering=True,
        )
    order = {id(c.instruction): i for i, c in enumerate(candidates)}
    best = min(admissible, key=lambda c: (c.cost, order[id(c.instruction)]))
    return SelectionReport(
        chosen=best.instruction,
        chosen_cost=best.cost,
        candidates=candidates,
        oracle_min_cost=best.cost,
        oracle_chosen=best.instruction,
        gap=0.0,
        no_admissible_lowering=False,
    )
