from dataclasses import dataclass

from triton_toyisa.ttir.lexer import Lexer, Token


@dataclass(frozen=True)
class RawLoc:
    name: str
    line: int | None = None
    col: int | None = None


@dataclass(frozen=True)
class RawBlock:
    args: list[tuple[str, str]]
    ops: list["RawOp"]
    terminator_index: int


@dataclass(frozen=True)
class RawRegion:
    blocks: list[RawBlock]


@dataclass(frozen=True)
class RawOp:
    name: str
    results: list[str | None]
    operands: list[str]
    attrs: dict[str, str]
    result_types: list[str]
    operand_types: list[str]
    regions: list[RawRegion]
    loc: RawLoc | None
    line: int
    col: int


@dataclass(frozen=True)
class ParseDiagnostic:
    kind: str
    line: int | None
    col: int | None
    expected: str | None
    found: str | None
    snippet: str | None
    layer: str


@dataclass(frozen=True)
class RawModule:
    ops: list[RawOp]
    loc_table: dict[str, RawLoc]
    source_path: str
    triton_version: str | None
    diagnostics: list[ParseDiagnostic]


class Parser:
    def __init__(self, text: str, source_path: str):
        self.lexer = Lexer(text)
        self.tokens = list(self.lexer.tokenize())
        self.pos = 0
        self.source_path = source_path
        self.diagnostics = []
        self.loc_table = {}
        self.depth = 0

    def peek(self) -> Token | None:
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return None

    def advance(self) -> Token | None:
        if self.pos < len(self.tokens):
            t = self.tokens[self.pos]
            self.pos += 1
            return t
        return None

    def error(self, msg: str, t: Token | None = None):
        if not t:
            t = self.peek()
        line = t.line if t else None
        col = t.col if t else None
        found = t.value if t else "EOF"
        self.diagnostics.append(
            ParseDiagnostic(
                kind="PARSE_UNSUPPORTED",
                line=line,
                col=col,
                expected=None,
                found=found,
                snippet=msg,
                layer="syntax",
            )
        )

    def skip_newlines(self):
        while self.peek() and self.peek().kind == "NEWLINE":
            self.advance()

    def parse_module(self) -> RawModule:
        ops = []

        while self.peek():
            self.skip_newlines()
            if not self.peek():
                break

            # Check for loc table definitions
            if self.peek().kind == "LOC_ID" and self.peek().value.startswith("#loc"):
                self.parse_loc_def_line()
                continue

            # Parse normal ops
            op = self.parse_op()
            if op:
                ops.append(op)
            else:
                # If parse_op failed, advance to avoid infinite loop
                self.advance()

        return RawModule(
            ops=ops,
            loc_table=self.loc_table,
            source_path=self.source_path,
            triton_version=None,
            diagnostics=self.diagnostics,
        )

    def parse_loc_def_line(self):
        # #loc1 = loc("path":1:2)
        loc_id = self.advance()
        line_tokens = []
        while self.peek() and self.peek().kind != "NEWLINE":
            line_tokens.append(self.advance())

        # Parse it
        if (
            len(line_tokens) >= 3
            and line_tokens[0].value == "="
            and line_tokens[1].value == "loc"
            and line_tokens[2].value == "("
        ):
            if (
                len(line_tokens) >= 8
                and line_tokens[3].kind == "STRING"
                and line_tokens[4].value == ":"
            ):
                self.loc_table[loc_id.value] = RawLoc(
                    name=loc_id.value, line=int(line_tokens[5].value), col=int(line_tokens[7].value)
                )
            else:
                self.loc_table[loc_id.value] = RawLoc(name=loc_id.value)

    def parse_op(self) -> RawOp | None:
        self.skip_newlines()
        start_tok = self.peek()
        if not start_tok:
            return None
        if start_tok.value == "}":
            return None

        if self.depth > 200:
            self.error("Nesting limit exceeded", start_tok)
            return None

        line_tokens = []
        has_region = False

        # Read the operation definition (up to NEWLINE or region '{')
        paren_depth = 0
        brace_depth = 0
        bracket_depth = 0

        while self.peek():
            t = self.peek()

            if t.value == "(":
                paren_depth += 1
            elif t.value == ")":
                paren_depth -= 1
            elif t.value == "[":
                bracket_depth += 1
            elif t.value == "]":
                bracket_depth -= 1
            elif t.value == "{":
                brace_depth += 1
            elif t.value == "}":
                brace_depth -= 1

            if t.kind == "NEWLINE":
                if paren_depth == 0 and brace_depth == 0 and bracket_depth == 0:
                    self.advance()
                    break
                else:
                    # Inside a nested structure, newline is just a token
                    pass

            # Check if this '{' starts a region.
            # In MLIR, a region '{' is either followed by NEWLINE, or starts a region-bearing op (module, func, scf.for)
            if t.value == "{" and paren_depth == 0 and bracket_depth == 0 and brace_depth == 1:
                next_t = self.tokens[self.pos + 1] if self.pos + 1 < len(self.tokens) else None
                prev_tok = line_tokens[-1] if line_tokens else None
                is_attr_dict = (prev_tok is not None and prev_tok.value == "attributes")
                is_end_of_line = (not next_t or next_t.kind == "NEWLINE")
                is_region_op = bool(line_tokens and line_tokens[0].value in ("module", "builtin.module", "func.func", "tt.func", "scf.for", "scf.if"))
                if not is_attr_dict and (is_end_of_line or (is_region_op and next_t and next_t.value != "value" and next_t.value != "end")):
                    has_region = True
                    self.advance()  # consume '{'
                    brace_depth -= 1
                    if self.peek() and self.peek().kind == "NEWLINE":
                        self.advance()
                    break

            if t.kind == "ERROR":
                self.error(f"Unknown token: {t.value}", t)

            line_tokens.append(self.advance())

        if brace_depth > 0 or paren_depth > 0 or bracket_depth > 0:
            self.error("Unterminated attribute dict or tuple", start_tok)

        if not line_tokens:
            return None

        # 1. Parse results and name
        results = []
        name_tok = None
        idx = 0

        if line_tokens[0].kind == "SSA_ID":
            eq_idx = -1
            for i, t in enumerate(line_tokens):
                if t.value == "=":
                    eq_idx = i
                    break
            if eq_idx != -1 and eq_idx + 1 < len(line_tokens):
                for res_tok in line_tokens[:eq_idx]:
                    if res_tok.kind == "SSA_ID":
                        if ":" in res_tok.value:
                            base, count = res_tok.value.split(":")
                            for ci in range(int(count)):
                                results.append(f"{base}#{ci}")
                        else:
                            results.append(res_tok.value)
                name_tok = line_tokens[eq_idx + 1]
                idx = eq_idx + 2
            else:
                idx = 0
                name_tok = line_tokens[idx]
                idx += 1
        else:
            # No results, first token is name
            idx = 0
            name_tok = line_tokens[idx]
            idx += 1

        if not name_tok or (name_tok.kind not in ("BARE_ID", "STRING")):
            self.error("Expected operation name", start_tok)
            return None

        # To find trailing loc, look from right: loc ( #loc1 )
        loc_tok = None
        right_idx = len(line_tokens) - 1
        if (
            right_idx >= 3
            and line_tokens[right_idx].value == ")"
            and line_tokens[right_idx - 2].value == "("
            and line_tokens[right_idx - 3].value == "loc"
        ):
            loc_tok = line_tokens[right_idx - 1]
            line_tokens = line_tokens[: right_idx - 3]

        # Find top-level colon for type signature
        colon_idx = -1
        p_depth = 0
        b_depth = 0
        br_depth = 0
        for i in range(idx, len(line_tokens)):
            t = line_tokens[i]
            if t.value in "([{":
                if t.value == "(": p_depth += 1
                elif t.value == "[": br_depth += 1
                elif t.value == "{": b_depth += 1
            elif t.value in ")]}":
                if t.value == ")": p_depth -= 1
                elif t.value == "]": br_depth -= 1
                elif t.value == "}": b_depth -= 1
            elif t.value == ":" and p_depth == 0 and br_depth == 0 and b_depth == 0:
                colon_idx = i
                break

        operands = []
        operand_end = colon_idx if colon_idx != -1 else len(line_tokens)
        if name_tok.value == "scf.for":
            for i, t in enumerate(line_tokens):
                if t.value == "scf.for" and i + 3 < len(line_tokens) and line_tokens[i + 2].value == "=":
                    if line_tokens[i + 3].kind == "SSA_ID":
                        operands.append(line_tokens[i + 3].value)
                elif t.value == "to" and i + 1 < len(line_tokens) and line_tokens[i + 1].kind == "SSA_ID":
                    operands.append(line_tokens[i + 1].value)
                elif t.value == "step" and i + 1 < len(line_tokens) and line_tokens[i + 1].kind == "SSA_ID":
                    operands.append(line_tokens[i + 1].value)
                elif t.value == "iter_args":
                    j = i + 1
                    while j < len(line_tokens) and line_tokens[j].value != ")":
                        if line_tokens[j].kind == "SSA_ID" and j + 2 < len(line_tokens) and line_tokens[j + 1].value == "=":
                            if line_tokens[j + 2].kind == "SSA_ID":
                                operands.append(line_tokens[j + 2].value)
                        j += 1
        elif name_tok.value != "tt.func":
            for i in range(idx, operand_end):
                t = line_tokens[i]
                if t.kind == "SSA_ID":
                    operands.append(t.value)

        operand_types = []
        result_types = []

        # Find -> if present at top-level
        arrow_idx = -1
        p_depth = 0
        for i, t in enumerate(line_tokens):
            if t.value in "(<[{":
                p_depth += 1
            elif t.value in ")>]}":
                p_depth -= 1
            elif t.value == "->" and p_depth == 0:
                arrow_idx = i
                break

        def split_types(toks):
            if not toks:
                return []
            if toks[0].value == "(" and toks[-1].value == ")":
                toks = toks[1:-1]
            types = []
            cur = []
            d = 0
            for tok in toks:
                if tok.value in "(<[{":
                    d += 1
                elif tok.value in ")>]}":
                    d -= 1
                elif tok.value == "," and d == 0:
                    if cur:
                        types.append("".join(x.value for x in cur))
                        cur = []
                    continue
                cur.append(tok)
            if cur:
                types.append("".join(x.value for x in cur))
            return types

        if arrow_idx != -1 and colon_idx != -1:
            if colon_idx < arrow_idx:
                # ... : op_types -> res_types
                op_t_toks = line_tokens[colon_idx + 1 : arrow_idx]
                res_t_toks = line_tokens[arrow_idx + 1 :]
            else:
                # ... -> (res_types) : op_types
                res_t_toks = line_tokens[arrow_idx + 1 : colon_idx]
                op_t_toks = line_tokens[colon_idx + 1 :]
            operand_types = split_types(op_t_toks)
            result_types = split_types(res_t_toks)
        elif arrow_idx != -1:
            res_t_toks = line_tokens[arrow_idx + 1 :]
            result_types = split_types(res_t_toks)
        elif colon_idx != -1:
            op_t_toks = line_tokens[colon_idx + 1 :]
            operand_types = split_types(op_t_toks)
            if results and operand_types:
                result_types = [operand_types[0]]

        # Block args for entry block of func or loop
        entry_block_args = []
        if name_tok.value == "tt.func":
            # Extract arguments from func signature: %arg: type
            f_pdepth = 0
            cur_arg_name = None
            cur_arg_type = []
            in_args = False
            for t in line_tokens[idx:]:
                if t.value == "(":
                    f_pdepth += 1
                    if f_pdepth == 1:
                        in_args = True
                        continue
                elif t.value == ")":
                    f_pdepth -= 1
                    if f_pdepth == 0:
                        if cur_arg_name and cur_arg_type:
                            entry_block_args.append((cur_arg_name, "".join(cur_arg_type)))
                        in_args = False
                        break
                if in_args:
                    if t.kind == "SSA_ID" and cur_arg_name is None:
                        cur_arg_name = t.value
                    elif t.value == ":" and cur_arg_name is not None and not cur_arg_type:
                        continue
                    elif cur_arg_name is not None:
                        if t.value == "loc" or t.value == ",":
                            entry_block_args.append((cur_arg_name, "".join(cur_arg_type)))
                            cur_arg_name = None
                            cur_arg_type = []
                        else:
                            cur_arg_type.append(t.value)
        elif name_tok.value == "scf.for":
            # %_k = ... iter_args(%a = %init, ...)
            # Extract loop induction var and iter_args
            for i, t in enumerate(line_tokens):
                if t.value == "scf.for" and i + 1 < len(line_tokens) and line_tokens[i + 1].kind == "SSA_ID":
                    entry_block_args.append((line_tokens[i + 1].value, "i32"))
                elif t.value == "iter_args":
                    j = i + 1
                    while j < len(line_tokens) and line_tokens[j].value != ")":
                        if line_tokens[j].kind == "SSA_ID" and j + 1 < len(line_tokens) and line_tokens[j + 1].value == "=":
                            arg_type_idx = len(entry_block_args) - 1
                            arg_type = result_types[arg_type_idx] if arg_type_idx < len(result_types) else "tensor<64x64xf32>"
                            entry_block_args.append((line_tokens[j].value, arg_type))
                        j += 1

        # 3. Parse Region if present
        regions = []
        if has_region:
            self.depth += 1
            region_ops = []
            while self.peek():
                self.skip_newlines()
                if self.peek() and self.peek().value == "}":
                    break
                if self.peek().kind == "LOC_ID" and self.peek().value.startswith("#loc"):
                    self.parse_loc_def_line()
                    continue

                child = self.parse_op()
                if child:
                    region_ops.append(child)
                else:
                    self.advance()

            end_brace = None
            if self.peek() and self.peek().value == "}":
                end_brace = self.advance()
            self.depth -= 1

            while self.peek() and self.peek().kind != "NEWLINE":
                t = self.advance()
                if t.value == "loc" and self.peek() and self.peek().value == "(":
                    self.advance()
                    lt = None
                    if self.peek() and self.peek().kind == "LOC_ID":
                        lt = self.advance()
                    if lt:
                        loc_tok = lt
                    self.advance()

            if not end_brace:
                self.error("Expected '}' to close region", None if not self.peek() else self.peek())

            regions.append(
                RawRegion(
                    blocks=[
                        RawBlock(
                            args=entry_block_args,
                            ops=region_ops,
                            terminator_index=len(region_ops) - 1 if region_ops else 0,
                        )
                    ]
                )
            )

        return RawOp(
            name=name_tok.value,
            results=results,
            operands=operands,
            attrs={},
            result_types=result_types,
            operand_types=operand_types,
            regions=regions,
            loc=RawLoc(name=loc_tok.value) if loc_tok else None,
            line=name_tok.line,
            col=name_tok.col,
        )


def parse_raw(text: str, *, source_path: str = "<string>") -> RawModule:
    parser = Parser(text, source_path)
    return parser.parse_module()
