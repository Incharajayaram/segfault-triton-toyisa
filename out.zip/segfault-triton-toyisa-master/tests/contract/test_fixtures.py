"""Contract tests for the fixture canon using standard library unittest.

Validates the frozen corpus and fixtures/GOLDEN.json against each other.
No dependency on pytest.
"""

from __future__ import annotations

import re
import unittest
from fixtures_lib import FIXTURES, load_golden, normalize, read_fixture, scan
from snapshot_fixtures import INTENT, check

ABS_PATH = re.compile(r'loc\("(/[^"]*)"')
TIERS = sorted(INTENT)


class TestFixturesContract(unittest.TestCase):
    """Contract tests verifying fixture stability and golden canon agreement."""

    def test_canon_agrees_with_fixtures(self) -> None:
        """Run snapshot check: fixture canon must agree with observations and intent."""
        self.assertEqual(check(), 0, "fixture canon drift: see snapshot_fixtures.check output")

    def test_recorded_hashes_match_files(self) -> None:
        golden = load_golden()
        for name in TIERS:
            with self.subTest(tier=name):
                expected_sha = golden["observations"][name]["sha256"]
                actual_sha = scan(read_fixture(name))["sha256"]
                self.assertEqual(
                    actual_sha,
                    expected_sha,
                    f"{name}: SHA256 hash mismatch between file and GOLDEN.json",
                )

    def test_every_recorded_observation_matches(self) -> None:
        golden = load_golden()
        for name in TIERS:
            with self.subTest(tier=name):
                observed = scan(read_fixture(name))
                for key, want in golden["observations"][name].items():
                    self.assertEqual(
                        observed[key],
                        want,
                        f"{name}.{key}: recorded {want!r}, observed {observed[key]!r}",
                    )

    def test_fixtures_have_no_absolute_paths(self) -> None:
        """Fixtures must not embed machine-dependent absolute source paths."""
        for name in TIERS:
            with self.subTest(tier=name):
                text = read_fixture(name)
                self.assertFalse(
                    ABS_PATH.search(text),
                    f"{name} embeds an absolute source path",
                )
                self.assertIn(
                    'loc("LOCFILE"',
                    text,
                    f"{name} was never normalized with LOCFILE",
                )

    def test_normalization_is_idempotent_and_total(self) -> None:
        for name in TIERS:
            with self.subTest(tier=name):
                raw = (FIXTURES / "raw" / f"{name}.ttir").read_text()
                once = normalize(raw)
                self.assertEqual(once, once.rstrip() + "\n")
                self.assertEqual(normalize(once), once, "normalize() must be a fixed point")
                self.assertEqual(
                    normalize(raw),
                    read_fixture(name),
                    "fixtures/ is not normalize(fixtures/raw/)",
                )


if __name__ == "__main__":
    unittest.main()
